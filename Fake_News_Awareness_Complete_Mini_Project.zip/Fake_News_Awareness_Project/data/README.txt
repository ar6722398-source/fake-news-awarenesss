Add your real labelled dataset here as news.csv.
Required columns: text,label
Suggested labels: REAL and FAKE
