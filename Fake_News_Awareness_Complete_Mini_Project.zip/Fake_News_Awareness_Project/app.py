import sqlite3
from pathlib import Path
import joblib
import streamlit as st
DB='fake_news.db'; MODEL='fake_news_pipeline.joblib'
def init_db():
    with sqlite3.connect(DB) as c: c.execute('CREATE TABLE IF NOT EXISTS predictions(id INTEGER PRIMARY KEY AUTOINCREMENT, news_text TEXT NOT NULL, prediction TEXT NOT NULL, confidence REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)')
def save(text,label,confidence):
    with sqlite3.connect(DB) as c: c.execute('INSERT INTO predictions(news_text,prediction,confidence) VALUES(?,?,?)',(text,label,confidence))
def rows():
    with sqlite3.connect(DB) as c: return c.execute('SELECT created_at,prediction,confidence,substr(news_text,1,120) FROM predictions ORDER BY id DESC LIMIT 50').fetchall()
st.set_page_config(page_title='Fake News Awareness',page_icon='📰',layout='wide'); init_db()
model=joblib.load(MODEL) if Path(MODEL).exists() else None
st.title('📰 Fake News Awareness & Detection System')
st.caption('Educational ML prototype. A prediction is not proof that a claim is true or false.')
page=st.sidebar.radio('Navigate',['Check News','Awareness','History','Model Info'])
if page=='Check News':
    text=st.text_area('Paste a headline or news article',height=220)
    if st.button('Analyse',type='primary'):
        if not text.strip(): st.warning('Please enter news text.')
        elif model is None: st.error('Train the model first: python train_model.py --data data/news.csv')
        else:
            pred=str(model.predict([text])[0]); conf=None
            if hasattr(model,'predict_proba'): conf=float(max(model.predict_proba([text])[0]))*100
            msg=f'Prediction: {"REAL" if pred=="REAL" else "POTENTIALLY FAKE"}' + (f' ({conf:.1f}% model confidence)' if conf else '')
            (st.success if pred=='REAL' else st.error)(msg); save(text,pred,conf)
            st.info('Verify important claims using the original source and multiple reputable sources.')
elif page=='Awareness':
    st.subheader('Fake-news awareness checklist'); st.markdown('''1. **Check the original source.**\n2. **Read beyond the headline.**\n3. **Check author, date and supporting evidence.**\n4. **Cross-check with multiple reputable or official sources.**\n5. **Check images and quotations in their original context.**\n6. **Avoid sharing an unverified claim.**''')
elif page=='History':
    st.subheader('Recent local predictions'); data=rows()
    if data: st.dataframe(data,use_container_width=True)
    else: st.info('No predictions stored yet.')
else:
    st.subheader('Model Information'); st.write('TF-IDF text features + Logistic Regression using Scikit-learn.')
    if Path('model_metrics.txt').exists(): st.code(Path('model_metrics.txt').read_text())
