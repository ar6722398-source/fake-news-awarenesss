# Fake News Awareness & Detection System

Mini project based on the submitted proposal. It uses Python, Streamlit, TF-IDF, Logistic Regression, Scikit-learn and SQLite.

## Dataset
Add a genuine labelled CSV as `data/news.csv` with columns `text,label`. Use consistent labels such as `REAL` and `FAKE`. No fabricated training dataset or fabricated accuracy is included.

## Windows setup
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python train_model.py --data data/news.csv
streamlit run app.py
```

## Output
Training generates `fake_news_pipeline.joblib` and `model_metrics.txt`. Using the application creates `fake_news.db` locally.

## Limitation
This is an educational text-classification prototype, not a professional fact-checking service. Predictions can be wrong and important claims should be independently verified.
