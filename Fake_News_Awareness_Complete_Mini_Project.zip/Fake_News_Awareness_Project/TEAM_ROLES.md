# Team Roles
## Ayush - ML and Data Processing Lead
Dataset preparation; train_model.py; TF-IDF; Logistic Regression; model training/testing; generated evaluation metrics.
## Ayush Rana - Web Development and Database Lead
app.py; Streamlit interface; trained-model integration; SQLite prediction history; awareness/history/model-information pages.
