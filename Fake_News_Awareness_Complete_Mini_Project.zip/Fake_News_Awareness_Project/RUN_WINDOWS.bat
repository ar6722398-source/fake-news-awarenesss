@echo off
python -m venv .venv
call .venv\Scripts\activate
python -m pip install -r requirements.txt
if not exist data\news.csv (
 echo Add your labelled dataset as data\news.csv first. Required columns: text,label
 pause
 exit /b 1
)
python train_model.py --data data/news.csv
streamlit run app.py
